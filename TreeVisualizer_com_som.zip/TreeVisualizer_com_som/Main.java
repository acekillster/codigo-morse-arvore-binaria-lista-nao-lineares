import java.util.Arrays;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.util.Scanner;

// arvore binaria de codigo morse: ponto (.) vai para a esquerda e traco (-) para a direita
public class Main {

    // no da arvore: guarda uma letra e os dois filhos
    static class No {
        char letra;   // espaco significa que o no nao tem letra
        No esquerda;  // caminho do ponto
        No direita;   // caminho do traco

        No(char letra) {
            this.letra = letra;
        }
    }

    // arvore que guarda o alfabeto e faz codificacao, decodificacao e impressao
    static class ArvoreMorse {
        private No raiz;

        // cria a raiz vazia e ja insere as letras
        ArvoreMorse() {
            raiz = new No(' ');
            carregarAlfabeto();
        }

        // desce pela arvore seguindo o codigo, criando os nos que faltam
        public void inserir(char letra, String codigo) {
            No atual = raiz;

            for (char simbolo : codigo.toCharArray()) {
                if (simbolo == '.') {
                    if (atual.esquerda == null) {
                        atual.esquerda = new No(' ');
                    }
                    atual = atual.esquerda;
                } else {
                    if (atual.direita == null) {
                        atual.direita = new No(' ');
                    }
                    atual = atual.direita;
                }
            }

            // o ultimo no do caminho recebe a letra
            atual.letra = letra;
        }

        // cada codigo esta na mesma posicao da sua letra (A = ".-", B = "-...")
        private void carregarAlfabeto() {
            String letras = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

            String[] codigos = {
                ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---",
                "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-",
                "..-", "...-", ".--", "-..-", "-.--", "--.."
            };

            for (int i = 0; i < letras.length(); i++) {
                inserir(letras.charAt(i), codigos[i]);
            }
        }

        // letras separadas por espaco e palavras separadas por /
        public String decodificar(String entrada) {
            if (entrada == null || entrada.trim().isEmpty()) {
                return "";
            }

            // espaco em volta da barra para ela virar uma parte separada
            String[] partes = entrada.trim().replace("/", " / ").split("\\s+");
            StringBuilder resultado = new StringBuilder();

            for (String parte : partes) {
                if (parte.equals("/")) {
                    resultado.append(' ');
                } else {
                    resultado.append(decodificarLetra(parte));
                }
            }

            return resultado.toString();
        }

        // anda pela arvore seguindo o codigo e devolve a letra onde parou
        private char decodificarLetra(String codigo) {
            No atual = raiz;

            for (char simbolo : codigo.toCharArray()) {
                if (simbolo == '.') {
                    atual = atual.esquerda;
                } else if (simbolo == '-') {
                    atual = atual.direita;
                } else {
                    return '?'; // simbolo que nao e morse
                }

                // caminho que nao existe na arvore
                if (atual == null) {
                    return '?';
                }
            }

            // no sem letra tambem e invalido
            return atual.letra == ' ' ? '?' : atual.letra;
        }

        // texto vira morse, com " / " entre palavras
        public String codificar(String texto) {
            if (texto == null || texto.trim().isEmpty()) {
                return "";
            }

            // a arvore so tem letras maiusculas
            String[] palavras = texto.trim().toUpperCase().split("\\s+");
            StringBuilder resultado = new StringBuilder();

            for (int i = 0; i < palavras.length; i++) {
                if (i > 0) {
                    resultado.append(" / ");
                }

                for (int j = 0; j < palavras[i].length(); j++) {
                    if (j > 0) {
                        resultado.append(' ');
                    }

                    String codigo = buscarCodigo(raiz, palavras[i].charAt(j), "");

                    // ? para caracteres que nao existem na arvore (numeros, simbolos)
                    resultado.append(codigo == null ? "?" : codigo);
                }
            }

            return resultado.toString();
        }

        // procura a letra na arvore; "caminho" acumula os pontos e tracos percorridos
        private String buscarCodigo(No no, char letra, String caminho) {
            if (no == null) {
                return null;
            }

            if (no.letra == letra) {
                return caminho;
            }

            // tenta a esquerda (ponto) e, se nao achar, a direita (traco)
            String codigo = buscarCodigo(no.esquerda, letra, caminho + ".");
            if (codigo == null) {
                codigo = buscarCodigo(no.direita, letra, caminho + "-");
            }
            return codigo;
        }

        public int calcularAltura() {
            return calcularAltura(raiz);
        }

        // altura = 1 (este no) + altura do lado mais fundo
        private int calcularAltura(No no) {
            if (no == null) {
                return 0;
            }
            return 1 + Math.max(calcularAltura(no.esquerda), calcularAltura(no.direita));
        }

        // imprime a arvore de cima para baixo, desenhando em uma grade de caracteres
        public void imprimirArvore() {
            int altura = calcularAltura();

            // a largura dobra a cada nivel para os nos de baixo nao ficarem colados
            int largura = (int) Math.pow(2, altura + 1);

            // cada nivel usa 3 linhas: no, barra e perna (o ultimo nivel so tem o no)
            int linhas = (altura - 1) * 3 + 1;

            char[][] grade = new char[linhas][largura];
            for (char[] linha : grade) {
                Arrays.fill(linha, ' ');
            }

            // a raiz fica no meio e os filhos se afastam metade a cada nivel
            preencherGrade(grade, raiz, 0, largura / 2, largura / 4);

            for (char[] linha : grade) {
                // replaceAll tira os espacos que sobram no fim da linha
                System.out.println(new String(linha).replaceAll("\\s+$", ""));
            }
        }

        // coloca o no na grade e liga ele aos filhos
        private void preencherGrade(char[][] grade, No no, int linha, int coluna, int deslocamento) {
            // a raiz nao tem letra, entao aparece como *
            grade[linha][coluna] = no.letra == ' ' ? '*' : no.letra;

            int colunaEsquerda = coluna - deslocamento;
            int colunaDireita = coluna + deslocamento;

            // barra horizontal indo da coluna do pai ate a dos filhos que existem
            if (no.esquerda != null || no.direita != null) {
                int inicio = no.esquerda != null ? colunaEsquerda : coluna;
                int fim = no.direita != null ? colunaDireita : coluna;

                for (int c = inicio; c <= fim; c++) {
                    grade[linha + 1][c] = '-';
                }
                grade[linha + 1][coluna] = '+';
            }

            // a perna de cada filho mostra o simbolo do caminho: ponto ou traco
            if (no.esquerda != null) {
                grade[linha + 1][colunaEsquerda] = '+';
                grade[linha + 2][colunaEsquerda] = '.';
                preencherGrade(grade, no.esquerda, linha + 3, colunaEsquerda, deslocamento / 2);
            }

            if (no.direita != null) {
                grade[linha + 1][colunaDireita] = '+';
                grade[linha + 2][colunaDireita] = '-';
                preencherGrade(grade, no.direita, linha + 3, colunaDireita, deslocamento / 2);
            }
        }
    }

    // toca um bipe usando a biblioteca de som que ja vem no java
    static class Som {
        // frequencia em hertz (agudo ou grave) e duracao em milissegundos
        static void tocar(int frequencia, int duracao) {
            try {
                // 8000 amostras por segundo, 8 bits, 1 canal (mono)
                float taxa = 8000f;
                AudioFormat formato = new AudioFormat(taxa, 8, 1, true, false);
                SourceDataLine linha = AudioSystem.getSourceDataLine(formato);
                linha.open(formato);
                linha.start();

                // monta a onda do som (seno) um byte por vez
                byte[] onda = new byte[(int) (taxa * duracao / 1000)];
                for (int i = 0; i < onda.length; i++) {
                    double angulo = 2.0 * Math.PI * i * frequencia / taxa;
                    onda[i] = (byte) (Math.sin(angulo) * 100);
                }

                linha.write(onda, 0, onda.length);
                linha.drain(); // espera o som terminar
                linha.close();
            } catch (Exception erro) {
                // sem placa de som, o programa segue normalmente sem tocar
            }
        }
    }

    // mostra a arvore e repete o menu ate o usuario digitar 0
    public static void main(String[] args) {
        ArvoreMorse arvore = new ArvoreMorse();
        Scanner leitor = new Scanner(System.in);
        int opcao = -1;

        System.out.println("ARVORE MORSE");
        System.out.println("esquerda = ponto (.) | direita = traco (-) | * = raiz\n");
        arvore.imprimirArvore();

        while (opcao != 0) {
            System.out.println("\n1 - decodificar morse");
            System.out.println("2 - codificar texto em morse");
            System.out.println("3 - imprimir arvore");
            System.out.println("4 - mostrar altura da arvore");
            System.out.println("0 - sair");
            System.out.print("escolha: ");

            String linha = leitor.nextLine().trim();

            // se digitarem algo que nao e numero, cai em "opcao invalida"
            try {
                opcao = Integer.parseInt(linha);
            } catch (NumberFormatException erro) {
                opcao = -1;
            }

            if (opcao == 1) {
                System.out.println("letras separadas por espaco e palavras por / (exemplo: ... --- ... / .-)");
                System.out.print("morse: ");
                String entrada = leitor.nextLine();

                if (entrada.trim().isEmpty()) {
                    System.out.println("nada foi digitado");
                } else {
                    System.out.println("texto: " + arvore.decodificar(entrada));
                    Som.tocar(700, 150);
                }
            } else if (opcao == 2) {
                System.out.print("texto: ");
                String entrada = leitor.nextLine();

                if (entrada.trim().isEmpty()) {
                    System.out.println("nada foi digitado");
                } else {
                    System.out.println("morse: " + arvore.codificar(entrada));
                    Som.tocar(900, 150);
                }
            } else if (opcao == 3) {
                arvore.imprimirArvore();
                Som.tocar(500, 200);
            } else if (opcao == 4) {
                System.out.println("altura da arvore: " + arvore.calcularAltura() + " niveis");
                Som.tocar(1100, 150);
            } else if (opcao != 0) {
                System.out.println("opcao invalida");
            }
        }

        System.out.println("encerrado");
        leitor.close();
    }
}
